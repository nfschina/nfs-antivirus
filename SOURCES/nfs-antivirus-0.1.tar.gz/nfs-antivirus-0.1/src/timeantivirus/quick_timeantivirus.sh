#!/bin/bash
echo "quick-scan" >> /tmp/.antivirus/log/.time_antivirus.txt
