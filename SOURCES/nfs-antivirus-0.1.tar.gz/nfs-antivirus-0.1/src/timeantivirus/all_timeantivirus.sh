#!/bin/bash
echo "all-scan" >> /tmp/.antivirus/log/.time_antivirus.txt
