sed -i 's/\t/,/g' /usr/lib/antivirus/NewAVL3bin/update.md5
sed -i 's/\t/,/g' /usr/lib/antivirus/AVL3bin/update.md5
