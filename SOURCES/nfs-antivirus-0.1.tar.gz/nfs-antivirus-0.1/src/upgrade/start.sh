cd /usr/lib/antivirus/upgrade
./upgrade
