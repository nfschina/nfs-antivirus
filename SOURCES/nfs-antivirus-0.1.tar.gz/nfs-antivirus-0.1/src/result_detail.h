/**
* Copyright (c) 2016-2018 CPU and Fundamental Software Research Center, CAS
*
* This software is published by the license of CPU-OS License, you can use and
* distibuted this software under this License. See CPU-OS Liense for more detail.
*
* You shoud have receive a copy of CPU-OS License. If not, please contact us 
* by email <support_os@cpu-os.ac.cn>
*
**/
void detail_result();
void switch_to_mainmenu();
void page_switch_to_result_detail(int cancel,int has_threat,int auto_deal,char *del_num,char *rep_num);
void detail_result(int cancel,int has_threat,int auto_deal,char *del_num,char *rep_num);
